package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.lang.reflect.Array;
import java.util.Arrays;

import static java.lang.reflect.Array.getLength;

public class AdvancedCalculator extends AppCompatActivity implements View.OnClickListener{

    Button calc_1;
    Button calc_2;
    Button calc_3;
    Button calc_4;
    Button calc_5;
    Button calc_6;
    Button calc_7;
    Button calc_8;
    Button calc_9;
    Button calc_0;
    Button calc_delete;
    Button calc_dec;
    Button calc_eq;
    EditText s_textinput;
    Button calc_reset;
    Button calc_mean;
    Button calc_median;
    Button calc_mode;
    Button calc_comm;

    float input1 = 0;
    float input2 = 0;
    float tempresult = 0;
    float result = 0;
    float[] set;

    String []tempset;
    int ctr = 0;
    float maxValue = 0;
    int maxCount = 0, k, j;
    String str = "";
    int i;
    char check = ' ';

    Boolean decimal = false;
    Boolean comma = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_calculator);
        initComponents();
    }

    public void initComponents(){
        //number buttons
        calc_1 = findViewById(R.id.calc_1);
        calc_2 = findViewById(R.id.calc_2);
        calc_3 = findViewById(R.id.calc_3);
        calc_4 = findViewById(R.id.calc_4);
        calc_5 = findViewById(R.id.calc_5);
        calc_6 = findViewById(R.id.calc_6);
        calc_7 = findViewById(R.id.calc_7);
        calc_8 = findViewById(R.id.calc_8);
        calc_9 = findViewById(R.id.calc_9);
        calc_0 = findViewById(R.id.calc_0);

        //operations
        calc_mean = findViewById(R.id.calc_mean);
        calc_median = findViewById(R.id.calc_median);
        calc_mode = findViewById(R.id.calc_mode);
        calc_eq = findViewById(R.id.calc_eq);
        calc_reset = findViewById(R.id.calc_reset);
        calc_comm = findViewById(R.id.calc_comm);

        //others
        calc_delete = findViewById(R.id.calc_delete);
        calc_dec = findViewById(R.id.calc_dec);
        s_textinput = findViewById(R.id.s_textinput);

        calc_0.setOnClickListener(this);
        calc_1.setOnClickListener(this);
        calc_2.setOnClickListener(this);
        calc_3.setOnClickListener(this);
        calc_4.setOnClickListener(this);
        calc_5.setOnClickListener(this);
        calc_6.setOnClickListener(this);
        calc_7.setOnClickListener(this);
        calc_8.setOnClickListener(this);
        calc_9.setOnClickListener(this);
        calc_eq.setOnClickListener(this);
        calc_reset.setOnClickListener(this);
        calc_delete.setOnClickListener(this);
        calc_dec.setOnClickListener(this);
        calc_mean.setOnClickListener(this);
        calc_median.setOnClickListener(this);
        calc_mode.setOnClickListener(this);
        calc_comm.setOnClickListener(this);




    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            //numberinput
            case R.id.calc_1:
                s_textinput.setText(s_textinput.getText() + "1");
                decimal = false;
                comma = false;

                break;
            case R.id.calc_2:
                s_textinput.setText(s_textinput.getText() + "2");
                decimal = false;
                comma = false;

                break;
            case R.id.calc_3:
                s_textinput.setText(s_textinput.getText() + "3");
                decimal = false;
                comma = false;

                break;
            case R.id.calc_4:
                s_textinput.setText(s_textinput.getText() + "4");
                decimal = false;
                comma = false;

                break;
            case R.id.calc_5:
                s_textinput.setText(s_textinput.getText() + "5");
                decimal = false;
                comma = false;

                break;
            case R.id.calc_6:
                s_textinput.setText(s_textinput.getText() + "6");
                decimal = false;
                comma = false;

                break;
            case R.id.calc_7:
                s_textinput.setText(s_textinput.getText() + "7");
                decimal = false;
                comma = false;

                break;
            case R.id.calc_8:
                s_textinput.setText(s_textinput.getText() + "8");
                decimal = false;
                comma = false;

                break;
            case R.id.calc_9:
                s_textinput.setText(s_textinput.getText() + "9");
                decimal = false;
                comma = false;

                break;
            case R.id.calc_0:
                s_textinput.setText(s_textinput.getText() + "0");
                decimal = false;
                comma = false;

                break;
            case R.id.calc_dec:
                if (decimal == true || comma == true) {
                    Toast.makeText(this, "Enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                s_textinput.setText(s_textinput.getText() + ".");
                decimal = true;
                comma = false;

                break;
            case R.id.calc_comm:
                if (s_textinput.getText().toString().matches("") || decimal == true || comma == true) {
                    Toast.makeText(this, "You did not enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                s_textinput.setText(s_textinput.getText()+ ",");
                decimal = false;
                comma = true;

                break;




            //operations
            case R.id.calc_mean:
                if (s_textinput.getText().toString().matches("")) {
                    Toast.makeText(this, "You did not enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                str = (s_textinput.getText() + "");
                tempset = str.split(",");

                for(i = 0; i < Array.getLength(tempset); i++ ){
                    tempresult = tempresult + Float.parseFloat(tempset[i]);
                }
                result = tempresult/i;
                s_textinput.setText(String.valueOf(result));
                break;

            case R.id.calc_median:
                if (s_textinput.getText().toString().matches("")) {
                    Toast.makeText(this, "You did not enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                str = (s_textinput.getText() + "");
                tempset = str.split(",");
                Arrays.sort(tempset);
                ctr = Array.getLength(tempset);

                if ((ctr % 2) == 0){
                    ctr = ctr/2;
                    tempresult = Float.parseFloat(tempset[ctr-1] + "") + Float.parseFloat(tempset[ctr] + "");
                    result = (float) (tempresult/2.0);
                }else {
                    ctr = ctr/2;
                    result = Float.parseFloat(tempset[ctr] + "");
                }
                s_textinput.setText(String.valueOf(result));
                break;

            case R.id.calc_mode:
                if (s_textinput.getText().toString().matches("")) {
                    Toast.makeText(this, "You did not enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                str = (s_textinput.getText() + "");
                tempset = str.split(",");
                for (k = 0; k < Array.getLength(tempset); k++) {
                    int count = 0;
                    for (j = 0; j < Array.getLength(tempset); j++) {
                        if (tempset[j] == tempset[k])
                            count++;
                    }

                    if (count > maxCount) {
                        maxCount = count;
                        maxValue = Float.parseFloat(tempset[k]+"");
                    }
                }
                s_textinput.setText(String.valueOf(maxValue));
                break;

            // others

            case R.id.calc_reset:
                s_textinput.setText(null);
                result = 0;
                ctr = 0;
                tempresult = 0;
                i = 0;
                k = 0;
                j = 0;

                break;

            case R.id.calc_delete:
                if (s_textinput.getText().toString().matches("")) {
                    Toast.makeText(this, "You did not enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                str = s_textinput.getText().toString();
                if ((str!= null) && (str.length() > 0 )){
                    str = str.substring(0, str.length() -1);
                    s_textinput.setText(str);
                }

                break;


        }

    }
}