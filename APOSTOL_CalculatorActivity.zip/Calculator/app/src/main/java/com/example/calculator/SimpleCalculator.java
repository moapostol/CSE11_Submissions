package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.lang.*;

public class SimpleCalculator extends AppCompatActivity implements View.OnClickListener{

    Button calc_1;
    Button calc_2;
    Button calc_3;
    Button calc_4;
    Button calc_5;
    Button calc_6;
    Button calc_7;
    Button calc_8;
    Button calc_9;
    Button calc_0;
    Button calc_plus;
    Button calc_minus;
    Button calc_multi;
    Button calc_divide;
    Button calc_delete;
    Button calc_dec;
    Button calc_eq;
    EditText s_textinput;
    Button calc_reset;

    float input1 = 0;
    float input2 = 0;
    float tempresult;
    float result = 0;
    int ctr = 0;

    Boolean plus = false;
    Boolean minus = false;
    Boolean multi = false;
    Boolean divide = false;
    Boolean operation = false;
    String str = "";
    Boolean decimal = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_calculator);
        initComponents();
    }

    public void initComponents(){
        //number buttons
        calc_1 = findViewById(R.id.calc_1);
        calc_2 = findViewById(R.id.calc_2);
        calc_3 = findViewById(R.id.calc_3);
        calc_4 = findViewById(R.id.calc_4);
        calc_5 = findViewById(R.id.calc_5);
        calc_6 = findViewById(R.id.calc_6);
        calc_7 = findViewById(R.id.calc_7);
        calc_8 = findViewById(R.id.calc_8);
        calc_9 = findViewById(R.id.calc_9);
        calc_0 = findViewById(R.id.calc_0);

        //operations
        calc_plus = findViewById(R.id.calc_plus);
        calc_minus = findViewById(R.id.calc_minus);
        calc_multi = findViewById(R.id.calc_multi);
        calc_divide = findViewById(R.id.calc_divide);
        calc_eq = findViewById(R.id.calc_eq);
        calc_reset = findViewById(R.id.calc_reset);

        //others
        calc_delete = findViewById(R.id.calc_delete);
        calc_dec = findViewById(R.id.calc_dec);
        s_textinput = findViewById(R.id.s_textinput);

        calc_0.setOnClickListener(this);
        calc_1.setOnClickListener(this);
        calc_2.setOnClickListener(this);
        calc_3.setOnClickListener(this);
        calc_4.setOnClickListener(this);
        calc_5.setOnClickListener(this);
        calc_6.setOnClickListener(this);
        calc_7.setOnClickListener(this);
        calc_8.setOnClickListener(this);
        calc_9.setOnClickListener(this);
        calc_plus.setOnClickListener(this);
        calc_minus.setOnClickListener(this);
        calc_multi.setOnClickListener(this);
        calc_divide.setOnClickListener(this);
        calc_eq.setOnClickListener(this);
        calc_reset.setOnClickListener(this);
        calc_delete.setOnClickListener(this);
        calc_dec.setOnClickListener(this);




    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            //numberinput
            case R.id.calc_1:
                s_textinput.setText(s_textinput.getText() + "1");
                decimal = false;

                break;
            case R.id.calc_2:
                s_textinput.setText(s_textinput.getText() + "2");
                decimal = false;

                break;
            case R.id.calc_3:
                s_textinput.setText(s_textinput.getText() + "3");
                decimal = false;

                break;
            case R.id.calc_4:
                s_textinput.setText(s_textinput.getText() + "4");
                decimal = false;

                break;
            case R.id.calc_5:
                s_textinput.setText(s_textinput.getText() + "5");
                decimal = false;

                break;
            case R.id.calc_6:
                s_textinput.setText(s_textinput.getText() + "6");
                decimal = false;

                break;
            case R.id.calc_7:
                s_textinput.setText(s_textinput.getText() + "7");
                decimal = false;

                break;
            case R.id.calc_8:
                s_textinput.setText(s_textinput.getText() + "8");
                decimal = false;

                break;
            case R.id.calc_9:
                s_textinput.setText(s_textinput.getText() + "9");
                decimal = false;

                break;
            case R.id.calc_0:
                s_textinput.setText(s_textinput.getText() + "0");
                decimal = false;

                break;
            case R.id.calc_dec:
                if (decimal == true) {
                    Toast.makeText(this, "Enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                s_textinput.setText(s_textinput.getText() + ".");
                decimal = true;
                break;


                //operations


            case R.id.calc_plus:
                if (s_textinput.getText().toString().matches("")) {
                    Toast.makeText(this, "You did not enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (decimal == true) {
                    Toast.makeText(this, "Enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                input1 = Float.parseFloat(s_textinput.getText() + "");
                s_textinput.setText(null);
                plus = true;
                minus = false;
                multi = false;
                divide = false;
                operation = true;
                break;


            case R.id.calc_minus:
                if (s_textinput.getText().toString().matches("")) {
                    Toast.makeText(this, "You did not enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (decimal == true) {
                    Toast.makeText(this, "Enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                input1 = Float.parseFloat(s_textinput.getText() + "");
                s_textinput.setText(null);
                plus = false;
                minus = true;
                multi = false;
                divide = false;
                operation = true;
                break;

            case R.id.calc_multi:
                if (s_textinput.getText().toString().matches("")) {
                    Toast.makeText(this, "You did not enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (decimal == true) {
                    Toast.makeText(this, "Enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                input1 = Float.parseFloat(s_textinput.getText() + "");
                s_textinput.setText(null);
                plus = false;
                minus = false;
                multi = true;
                divide = false;
                operation = true;
                break;

            case R.id.calc_divide:
                if (s_textinput.getText().toString().matches("")) {
                    Toast.makeText(this, "You did not enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (decimal == true) {
                    Toast.makeText(this, "Enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                input1 = Float.parseFloat(s_textinput.getText() + "");
                s_textinput.setText(null);
                plus = false;
                minus = false;
                multi = false;
                divide = true;
                operation = true;
                break;

            case R.id.calc_eq:
                if (s_textinput.getText().toString().matches("")) {
                    Toast.makeText(this, "You did not enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (decimal == true) {
                    Toast.makeText(this, "Enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                input2 = Float.parseFloat(s_textinput.getText() + "");
                if(plus == true){
                    result = input1 + input2;
                }else if(minus == true){
                    result = input1 - input2;
                }else if(multi == true){
                    result = input1 * input2;
                }else if (divide == true){
                    result = input1 / input2;
                }
                ctr = 0;
                s_textinput.setText(null);
                s_textinput.setText(String.valueOf(result));
                break;


                // others

            case R.id.calc_reset:
                s_textinput.setText(null);
                input1 = 0;
                input2 = 0;
                result = 0;
                ctr = 0;
                plus = false;
                minus = false;
                multi = false;
                divide = false;
                decimal = false;
                break;

            case R.id.calc_delete:
                if (s_textinput.getText().toString().matches("")) {
                    Toast.makeText(this, "You did not enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }
                str = s_textinput.getText().toString();
                if ((str!= null) && (str.length() > 0 )){
                    str = str.substring(0, str.length() -1);
                    s_textinput.setText(str);
                }

                break;


        }

    }
}