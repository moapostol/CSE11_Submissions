package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button simp_button;
    Button adv_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();

    }

    public void initComponents(){
        simp_button = findViewById(R.id.simp_button);
        adv_button = findViewById(R.id.adv_button);

        simp_button.setOnClickListener(this);
        adv_button.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.simp_button:
                Intent start_sc =new Intent(this, SimpleCalculator.class);
                startActivity(start_sc);
                break;

            case R.id.adv_button:
                Intent start_ac = new Intent(this, AdvancedCalculator.class);
                startActivity(start_ac);
                break;

        }

    }
}